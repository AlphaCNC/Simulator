#include <dos.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#define __CPPARGS ...
#define basa 0x2f8
#define vect 0x0b
#define eirq 0x0f7
#define dirq 0x08
#define ncom 0x01
#define nrate 0x08
#define opros 77

int fox;

static char rs_[]  = { 0,0,0,0,0,0,0,0,0,0,0,0 };
static char sp_0[] =
{
0x04,0x30,0x31,0x02,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x03,0
x00 };
static char sp_1[] =
{
0x04,0x30,0x31,0x02,0x33,0x30,0x30,0x31,0x30,0x30,0x30,0x30,0x03,0
x00 };
static char sp_3_0[] =
{
0x04,0x30,0x31,0x02,0x33,0x30,0x30,0x33,0x30,0x30,0x30,0x30,0x03,0
x00 };
static char sp_3_1[] =
{
0x04,0x30,0x31,0x02,0x33,0x30,0x30,0x33,0x30,0x30,0x30,0x31,0x03,0
x00 };

void pusk_rs (void);
void stop_rs (void);
void put_keb(char *);
int  get_keb(void);
void dec_to_ascii(int);
void trans(unsigned int vol);
void interrupt handler (__CPPARGS);
void interrupt (*oldhandler) (__CPPARGS);

void main(void)
{
 int speed=1000;

 pusk_rs();
 put_keb(&sp_0[0]);
 put_keb(&sp_3_0[0]);
 put_keb(&sp_1[0]);
 speed<<=1;
 dec_to_ascii(speed);
 put_keb(&sp_3_1[0]);
 put_keb(&sp_1[0]);
 delay(1000);
 printf("\n\t Speed... %5d", get_keb());
 delay(3000);
 put_keb(&sp_3_0[0]);
 stop_rs();
 exit(EXIT_SUCCESS);
}

void pusk_rs (void)
{
 _AH=0x04;        // function 04 int 14
 _AL=0x00;        // not break
 _BH=0x02;         // even parity
 _BL=0x00;         // 1 stop bit
 _CH=0x02;         // long word 7 bit
 _CL=nrate;       // 05h-2400; 06h-4800; 07h-9600; 08h-19200
 _DX=ncom;        // 1 - COM2; 0 - COM1
 geninterrupt(0x14);
// 57600
 outportb(basa+3, inportb(basa+3) | 0x80);
 outport(basa, 0x0002);
 outportb(basa+3, inportb(basa+3) & 0x7f);
//
 oldhandler=_dos_getvect(vect);
 _dos_setvect(vect,handler);
 _disable();
 outportb(0x21,inportb(0x21) & eirq);
 outportb(basa+3,inportb(basa+3) & 0x7f);
 outportb(basa+1,1);
 inportb(basa);
 inportb(basa+5);
 inportb(basa+6);
 outportb(basa+4,inportb(basa+4) | 0x08);
 _enable();
}

void stop_rs (void)
{
 _disable();
 outportb(0x21,inportb(0x21) | dirq);
 outportb(basa+3,inportb(basa+3) & 0x7f);
 outportb(basa+1,0x00);
 outportb(basa+4,inportb(basa+4) & 0x0f7);
 _enable();
 _dos_setvect(vect,oldhandler);
}

void interrupt handler (__CPPARGS)
{
 if (fox < 12) rs_[fox++]=inportb(basa);
 outportb(0x20,0x20);
}

void trans(unsigned int vol)
{
 while ((inportb(basa+5) & 0x32) == 0);
 outportb(basa,vol);
}

void dec_to_ascii(int vol)
{
 int i, j = 0;
 char st[4] = { 0,0,0,0 };

 for (i = 8; i < 12; i++) sp_1[i]=0x30;
 itoa(vol, st, 16);
 for (i = 0; i < 4; i++)
 {
  if (st[i] != 0) j++;
  if (st[i] > 0x60 && st[i] < 0x67) st[i]-=0x20;
 }
 switch (j)
 {
  case 1:
  sp_1[11]=st[0]; break;
  case 2:
  sp_1[10]=st[0]; sp_1[11]=st[1]; break;
  case 3:
  sp_1[9]=st[0]; sp_1[10]=st[1]; sp_1[11]=st[2]; break;
  case 4:
  sp_1[8]=st[0]; sp_1[9]=st[1]; sp_1[10]=st[2]; sp_1[11]=st[3];
break;
 }
}

void put_keb(char *mtv)
{
 int i;
 char bcc;

 bcc=*(mtv+4);
 for (i = 5; i < 13; i++) bcc^=*(mtv+i);
 if (bcc < 0x20) bcc+=0x20;
 *(mtv+13)=bcc;
 fox=0;
 for (i = 0; i < 14; i++) trans(*(mtv+i));
 delay(555);
}

int get_keb()
{
 long l=0;
 int i, j, k=0;
 char *str="0000", *endptr;
 static char cp1[] = { 0x04,0x30,0x31,0x32,0x30,0x30,0x31,0x05 };

 for (i = 0; i < opros; i++)
 {
  fox=0;
  if (i == 0) for (j = 0; j < 8; j++) trans(cp1[j]); else
trans(0x15);
  delay(10);
  if (fox == 11)
  {
   k++;
   str[0]=rs_[5];
   str[1]=rs_[6];
   str[2]=rs_[7];
   str[3]=rs_[8];
   l+=strtol(str, &endptr, 16);
  }
 }
 if (k == 0) return (0); else return ((int)(l/(k << 1)));
}



