/*  Demoprogram 66tstc.c
    supplies DIN66019-protocol for KEB-Combivert inverters in C
    KEB-Antriebstechnik, F�rsterweg 38, 4924 Barntrup
    Author : Kaiser,T.           27.July 1992

    written with Microsoft QuickC 2.01
    for building the "EXE"-Program :
    compile in LARGE-Model and
    link with 66019c.obj              */

#define COMM_IDLE 0
#define COMM_READ 1
#define COMM_WRITE 2
#define TIMEOUT  5000

#include <stdio.h>
#include <graph.h>
#include <bios.h>
#include <ctype.h>
#include <dos.h>



/* define array for communication  */
int comarray[10];

/* define array for status-strings    */
char statusname[28][50]={
   {"transm. ready-waiting for acknowledge\0"},
   {"transmitting running\0"},
   {"ready for analyzing\0"},
   {"function running\0"},
   {"code_19\0"},
   {"code_18\0"},
   {"code_17\0"},
   {"code_16\0"},
   {"code_15\0"},
   {"code_14\0"},
   {"code_13\0"},
   {"code_12\0"},
   {"code_11\0"},
   {"Serial adapter not ready\0"},
   {"code_9\0"},
   {"invalid function\0"},
   {"Parity-error\0"},
   {"Overrun-error\0"},
   {"Framing-error\0"},
   {"Invalid acknowledge / telegram-length\0"},
   {"Invalid start character\0"},
   {"BCC-Error\0"},
   {"Time-Out\0"},
   {"OK\0"},
   {"code_1\0"},
   {"Invalid parameter-address\0"},
   {"Invalid data\0"},
   {"Parameter read-only\0"},
};


/* Prototyping of external and internal functions */
extern void COMMUNICATE(int *, int *);
void showvals(void);
void analyze();
void enterval (int offset);
void readword(void);
void writeword(void);

/*  this variables are commonly used  */
int status, dismode, communication_state, ttick, comaddr, baud_10, modecom;
unsigned key, *tmp_ptr;



/* main programm beginns here */
void main(void){

comaddr = 0x3F8;                     /* set portaddress to COM1 */
/* comaddr = 0x2F8;                    set portaddress to COM2 */

baud_10 = 960;                       /* set baudrate to 9600 (n*10) */
modecom = 0x1A;                      /* set mode to 7 databits
                                                    1 stoppbit
                                                    even parity */

ttick = 0;                         /*this variable can be used for time-out
                                     detection and which is incremented every
                                     1 ms by timer-tick routine */

status = 0;                        /*this variable shows communication events
                                     and will be set by asm-routines during
                                     receiving-interrupts in background */

/* put in the address of the serial adapter for all later function calls */
comarray[6] = comaddr;

/* initiate serial link and set interrupt-serviceroutines for
   communication and timertick */
comarray[0] = baud_10;        /* Baudrate / 10 */
comarray[1] = 1;              /* Function- No */
comarray[2] = modecom;        /* Mode of serial adapter */
tmp_ptr = &ttick;             /* get adress of variable ttick */
comarray[3] = FP_SEG(tmp_ptr);/* store segment address of variable */
comarray[4] = FP_OFF(tmp_ptr);/* store offset address of variable */
/* call the communication function */
COMMUNICATE (&status, &comarray[0]);

/* set comm-state to idle */
communication_state = COMM_IDLE;
/* init communication parameters */
comarray[0] = 1;              /* Slave no */
comarray[2] = 513;            /* parameter address */
comarray[3] = 0;              /* data */

/* display main image  */
showvals();

/* main loop  */
 for (;;){

 do{
  key = 0;
  if (_bios_keybrd( _KEYBRD_READY ) != 0)     /* check if keystroke waiting */
     key =_bios_keybrd( _KEYBRD_READ ) ;      /* and read it if available */

  /* display value of time-out variable if comm running */
  if (communication_state != COMM_IDLE){
    _settextposition(7, 50);
    printf ("Timer-tick: %d",ttick);
  }

  /* check variable STATUS */
  if (communication_state != COMM_IDLE){
    _settextposition(8, 1);
    printf( "\nStatus   :%d",status);
    printf("\t%s       ",&statusname[status+23][0]);
  }


  /* reset comm after 5 sec without response */
    if (ttick > TIMEOUT && communication_state != COMM_IDLE) {
      communication_state = COMM_IDLE;
      status = -1;
      showvals();
    }

  if (status == -21) analyze();           /* acknowledge arrived !! */

 } while (key == 0);

  key = toupper(key & 0xFF);

switch (key) {
  case 88:                                      /* switch to hexa-notation */
    dismode = 1;
    showvals();
    break;
  case 90:                                      /* switch to dec-notation */
    dismode = 0;
    showvals();
    break;
  case 82:
    if (communication_state != COMM_IDLE){       /* if comm runs... */
      communication_state = COMM_IDLE;           /* terminate comm */
      status = -1;                               /* and set status to time-out */
    }
    showvals();
    readword();                               /* do the read-function */
    showvals();                               /* and display all  */
    break;
  case 87:
    if (communication_state != COMM_IDLE){       /* if comm runs... */
      communication_state = COMM_IDLE;           /* terminate comm */
      status = -1;                               /* and set status to time-out */
    }
    showvals();
    writeword();                               /* do the write-function */
    showvals();                               /* and display all  */
    break;
  case 83:
    if (communication_state != COMM_IDLE){       /* if comm runs... */
      communication_state = COMM_IDLE;           /* terminate comm */
      status = -1;                               /* and set status to time-out */
    }
    showvals();
    enterval(0);                              /* get slave-address from user */
    showvals();                               /* and display all  */
    break;
  case 68:
    if (communication_state != COMM_IDLE){       /* if comm runs... */
      communication_state = COMM_IDLE;           /* terminate comm */
      status = -1;                               /* and set status to time-out */
    }
    showvals();
    enterval(3);                              /* get data from user */
    showvals();                               /* and display all  */
    break;
  case 65:
    if (communication_state != COMM_IDLE){       /* if comm runs... */
      communication_state = COMM_IDLE;           /* terminate comm */
      status = -1;                               /* and set status to time-out */
    }
    showvals();
    enterval(2);                              /* get parameter-address from user */
    showvals();                               /* and display all  */
    break;
  case 81:
    /* don't forget to call this interrupt-reset routine !!!! */
    comarray[1]=2;                         /* function reset all */
    COMMUNICATE(&status, &comarray[0]);
    exit(0);
    break;
  default:
    break;
  }/* end switch  */
  key = 0;
 }/* end for */
} /* end main */




/*##################################################################*/
void analyze(){
/* get answer or errorcode from communication-routines  */

/* check if no comm running - this should never happen at this point !! */

if (communication_state == COMM_IDLE) return;

if (communication_state == COMM_READ)       /* read running       */
      comarray[1] = 0x13;                   /* set function to analyze read */

if (communication_state == COMM_WRITE)      /* write running */
      comarray[1] = 0x14;                   /* set function to analyze write */


/* call the desired function */
COMMUNICATE(&status, &comarray[0]);

/* the variable 'status' contains now one of the following codes:
    0 = ok- no error detected and data valid
   -2 = error BCC
   -3 = invalid start character
   -4 = invalid acknowledge / telegram length
   -5 = framing error
   -6 = overrun-error  (should never occur because of interrupt-mode)
   -7 = parity error */

/* Reset communication_state  */
communication_state = COMM_IDLE ;

/* display new data and status  */
showvals();

} /* end function */


/*##################################################################*/
void enterval (int offset){
/* get data from user and put it into comarray(offset)  
 DO NOT TERMINATE INPUT WITH CTRL-C BECAUSE PROGRAM EXECUTION STOPS
 IMMEDIATELY WITHOUT RESETTING INTERRUPT VECTORS AND SYSTEM HANGS UP !! */


if (offset == 0) printf("Enter slave-no. ");
if (offset == 2) printf("Enter parameter-address ");
if (offset == 3) printf("Enter data ");

scanf( "%i", &comarray[offset]);

/* clear input buffer */
fflush( stdin );

} /* end function */


/*##################################################################*/
void readword(void){

comarray[1] = 0x11;                       /* set function to initiate read   */

/* call the desired function   */
COMMUNICATE(&status, &comarray[0]);

/* the variable 'status'  now contains one of the following codes:
   -8  = invalid function (only if reading from inverter-group-addresses)
   -10 = serial adapter not ready
   -20 = function up and running
   -21 = got acknowledge - ready for analyzing
   -22 = transmitting in progress
   -23 = transmitting ready - waiting for acknowledge

   this variable will be checked later in main-loop.  */

/* Set communication_state to correct value  */
communication_state = COMM_READ;

/* reset timeout-counter */
ttick = 0;

} /* end function */


/*##################################################################*/
void showvals(void){
/* display all values and com-status  */

_clearscreen(_GCLEARSCREEN);
printf("\n\t\tKEB-ANTRIEBSTECHNIK  DIN 66019-TEST V2.0\n");
printf("\t\t            - C-Version -\n");
printf("\n\n");
printf( "SLAVE-No.:");
if (dismode == 0) printf("%d",comarray[0]);
if (dismode == 1) printf("%xH",comarray[0]);

printf( "\nADDRESS  :");
if (dismode == 0) printf("%d",comarray[2]);
if (dismode == 1) printf("%xH",comarray[2]);

printf( "\nDATA     :");
if (dismode == 0) printf("%d",comarray[3]);
if (dismode == 1) printf("%xH",comarray[3]);

printf( "\nStatus   :%d",status);
printf("\t%s",&statusname[status+23][0]);

printf("\n");
printf("\n");
printf("\n");
printf( "Enter S to change the slave address \n");
printf( "      A to change the parameter address\n");
printf( "      D to change the data\n");
printf( "      R to read a parameter\n");
printf( "      W to write a parameter\n");
printf( "      X for hexadecimal notation\n");
printf( "      Z for decimal notation\n");
printf( "      Q to quit this program\n");
} /* end function */


/*##################################################################*/
void writeword(void){

comarray[1] = 0x12;                      /* set function to initiate write  */

/* call the desired function  */
COMMUNICATE(&status, comarray);

/* the variable 'status'  now contains one of the following codes:
    0  = ok   (only when writing to Inverter-group-adresses)
   -8  = unknown function
   -10 = serial adapter not ready
   -20 = function up and running
   -21 = got acknowledge - ready for analyzing
   -22 = transmitting in progress
   -23 = transmitting ready - waiting for acknowledge

   this variable will be checked later in main-loop. */


/* Set communication_state to correct value   */
communication_state = COMM_WRITE;

/* reset timeout-counter  */
ttick = 0;

} /* end function */
